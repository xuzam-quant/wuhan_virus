# -*- coding: utf-8 -*-
"""
Created on Mon May 13 11:21:39 2019

@author: zhangxu
"""

import numpy as np
import pandas as pd
import os
import sys
from openpyxl import load_workbook
from asim import traxexcore
sys.path.append(os.getcwd()+'\\PyLib')
from FunctionList import *

start_date = np.datetime64('2019-02-01')
end_date   = np.datetime64('today') + np.timedelta64(1,'D')

filename_excel    = 'mday_report_summary_2019.xlsx'
sheetname_account = 'TradeAccount'
sheetname_symbol  = 'SymbolInfor'
foldername_order  = 'Data\\MDay\\Account\\'

trade_account_list = pd.read_excel(filename_excel, sheetname=sheetname_account)
tc = traxexcore.TraxexCore('.\\traxexcore.xml')
#%% download all trade record
if os.path.exists(foldername_order)==0:
    os.makedirs(foldername_order)
period = int((end_date - start_date)/np.timedelta64(1,'D')+1)
df_orders_all = pd.DataFrame([])
for trade_account in trade_account_list.Account:
    try:
        print(trade_account)
        df_orders = func_traderecord_download(trade_account, period, traxexcore)
        
        temp=foldername_order+trade_account+'\\'
        if os.path.exists(temp)==0:
            os.mkdir(temp)
        df_orders.to_csv(temp+trade_account+'.csv', index=True)
        
        if len(df_orders_all)==0:
            df_orders_all = df_orders.copy()
        else:
            df_orders_all = df_orders_all.append(df_orders)
        
    except:
        print('Error!')
        
#%% get symbol reference information        
df_symbol_infor = func_traderecord_symbol_infor(df_orders_all, traxexcore)

book = load_workbook(filename_excel)
writer = pd.ExcelWriter(filename_excel, engine='openpyxl')
writer.book = book
del writer.book[sheetname_symbol]
writer.sheets = dict((ws.title,ws) for ws in book.worksheets)
df_symbol_infor.to_excel(writer, sheet_name=sheetname_symbol, index=False)
writer.save()