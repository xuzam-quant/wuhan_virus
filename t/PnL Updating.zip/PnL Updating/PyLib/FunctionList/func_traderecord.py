# -*- coding: utf-8 -*-
"""
Created on Mon May 13 13:42:20 2019

@author: zhangxu
"""

import pandas as pd
import numpy as np

#%% trade record download
def func_traderecord_download(trade_account, period, traxexcore):
    params = dict(usd_id=11, acc=trade_account, period=str(period)+'d')
    orders = traxexcore.ctx.get_trades(params)
    
    acc = []
    tm = []
    px = []
    qty = []
    side = []
    sym = []    
    exch = []
    asset = []
    for i in range(len(orders)):
        acc.append(orders[i].acc)
        tm.append(orders[i].tm)
        px.append(orders[i].px)
        side.append(orders[i].side)
        if orders[i].side=='buy':
            dir=1
        else:
            dir=-1
        qty.append(orders[i].qty*dir)        
        sym.append(orders[i].symbol.ticker)
        exch.append(orders[i].symbol.market)
        asset.append(orders[i].symbol.type)
        
    df_orders = pd.DataFrame({'time':tm, 'symbol':sym,'price':px,'quantity':qty,'side':side,'account':acc,'exchange':exch,'asset':asset})    
    df_orders['time'] = pd.to_datetime(df_orders['time'])
    df_orders.set_index('time', inplace=True)
    return df_orders

#%% symbol information from order and database
def func_traderecord_symbol_infor(df_orders_all, traxexcore):
    symbol_list = df_orders_all.symbol.unique()
    symbol_infor = []
    for symbol in symbol_list:
        idx=np.where(df_orders_all.symbol==symbol)[0]
        if len(idx)==0:
            exchange=''
        else:
            if df_orders_all.asset[idx[0]]=='EQUITY':
                exchange=' '+df_orders_all.exchange[idx[0]]
            else:
                exchange=''
        sec = traxexcore.get_symbol(symbol+exchange)    
        if sec.type=='INDEX' or sec.type=='COMDTY':        
            multiplier = sec.contract_size
        else:
            multiplier = 1
        if sec.type=='CURNCY':
            currency = symbol[3:]
        else:
            currency = sec.currency
        if multiplier<=0:
            print(symbol+' - multiplier error!')    
        symbol_infor_temp = [sec.ticker, currency, sec.type, multiplier, exchange]
        symbol_infor.append(symbol_infor_temp)    
    df_symbol_infor = pd.DataFrame(symbol_infor, columns=['symbol','currency','asset','multiplier','exchange'])
    return df_symbol_infor