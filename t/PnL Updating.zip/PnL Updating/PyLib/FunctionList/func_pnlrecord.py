# -*- coding: utf-8 -*-
"""
Created on Tue May 14 10:15:59 2019

@author: zhangxu
"""

import numpy as np
import pandas as pd
import math
import datetime

#%% calculate pnl from orders
def func_pnlrecord_get_pnl(df_orders, stats_settle_time_beg, stats_settle_time_end, account_infor, instrument_infor, dict_currency2value, \
                           pnl_columns=['instrument', 'pnl_raw', 'converter', 'pnl_final', 'asset', 'amt_net_sum', 'accounting', 'trade_account', 'trade_strategy', 'date']):
    
    trade_account  = account_infor['Account']
    trade_strategy = account_infor['Strategy']
    
    df_orders_stats = df_orders.sort_values(by='time',ascending=True)
    # here may add new timestamps for timezone convert
    df_orders_stats.set_index('time', inplace=True)
    df_orders_stats.sort_index(ascending=True, inplace=True)            
    df_orders_stats = df_orders_stats[stats_settle_time_beg:stats_settle_time_end]
                    
    # order adjust and pnl stats
    position_pair = df_orders_stats.symbol.unique()
    orders_endofstats = []
    orders_liveexposure = []
    orders_noprice = []
    pnl_stats = [[None]*len(pnl_columns) for _ in range(len(position_pair))]
    pnl_sum = 0
    if len(position_pair)>0:
        for idx_position in range(len(position_pair)):
            try:
                # add order adjust the endofstats
                instrument_ticker_temp = position_pair[idx_position]                  
                idx_order = np.where(df_orders_stats.symbol==instrument_ticker_temp)[0]
                if len(idx_order)==0:
                    continue
                idx_instrument = [i for i in range(len(instrument_infor)) if instrument_infor[i][0]==instrument_ticker_temp]
                if len(idx_instrument)==0:
                    continue
                
                amt_adj = -1 * df_orders_stats.quantity[idx_order].sum()
                if amt_adj!=0:
                    if amt_adj>0:
                        side_adj='buy'
                    else:
                        side_adj='sell'                                                
                    df_bar_temp = instrument_infor[idx_instrument[0]][1]['price'][stats_settle_time_beg:stats_settle_time_end]
                    if len(df_bar_temp)==0:
                        time_adj  = stats_settle_time_end
                        close_adj = 0
                    else:
                        time_adj  = df_bar_temp.index[-1]
                        close_adj = df_bar_temp.close[-1]                        
                    orders_endofstats.append([time_adj, instrument_ticker_temp, close_adj, amt_adj, side_adj, trade_account])                    
                else:
                    close_adj=0
                #print(instrument_ticker_temp+'- finish!')
                
                # pnl stats
                pnl_stats[idx_position][0] = instrument_ticker_temp                        
                pnl_stats[idx_position][1] = - ((df_orders_stats.price[idx_order] * df_orders_stats.quantity[idx_order]).sum() + close_adj*amt_adj)
                pnl_stats[idx_position][2] = instrument_infor[idx_instrument[0]][1]['multiplier'] * dict_currency2value[instrument_infor[idx_instrument[0]][1]['currency']]
                pnl_stats[idx_position][3] = pnl_stats[idx_position][1] * pnl_stats[idx_position][2]
                pnl_stats[idx_position][4] = instrument_infor[idx_instrument[0]][1]['asset']
                pnl_stats[idx_position][5] = df_orders_stats.quantity[idx_order].sum() + amt_adj
                pnl_stats[idx_position][6] = 'Valuation'
                pnl_stats[idx_position][7] = trade_account
                pnl_stats[idx_position][8] = trade_strategy
                #pnl_stats[idx_position][9] = stats_settle_time_end.strftime("%Y-%m-%d")
                pnl_stats[idx_position][9] = (stats_settle_time_end.date()-datetime.date(1899,12,30)).days
                pnl_sum = pnl_sum + pnl_stats[idx_position][3]                        
                
                if amt_adj!=0:
                    orders_liveexposure.append([trade_account, stats_settle_time_end.date(), instrument_ticker_temp, -amt_adj*close_adj*pnl_stats[idx_position][2], \
                                                -amt_adj, close_adj, pnl_stats[idx_position][2], time_adj])
                    
                idx_noprice = np.where(df_orders_stats.price==0)[0]
                if len(idx_noprice)!=0:
                    tm=df_orders_stats.index.values[idx_noprice]
                    px=df_orders_stats.price.values[idx_noprice]
                    qty=df_orders_stats.quantity.values[idx_noprice]
                    side=df_orders_stats.side.values[idx_noprice]
                    for x in range(len(idx_noprice)):                    
                        orders_noprice.append([stats_settle_time_end.date(), tm[x], trade_account, px[x], \
                                               qty[x], side[x], instrument_ticker_temp, 'raworder'])
                elif amt_adj!=0 and close_adj==0:
                    orders_noprice.append([stats_settle_time_end.date(), stats_settle_time_end, trade_account, close_adj, amt_adj, side_adj, instrument_ticker_temp, 'noprice'])
                elif pnl_stats[idx_position][2]==0:
                    orders_noprice.append([stats_settle_time_end.date(), stats_settle_time_end, trade_account, close_adj, amt_adj, side_adj, instrument_ticker_temp, 'multiplier'])
                    
                    
            except:
                print('--------')
                print('Account :'+trade_account)
                print(instrument_ticker_temp+'- order&pnl error!')                    

    df_orders_endofstats = pd.DataFrame(orders_endofstats, columns=['time','symbol','price','quantity','side','account'])
    df_orders_endofstats.set_index('time', inplace=True)
    df_orders_stats_pnl = df_orders_stats.append(df_orders_endofstats)
    pnl_stats_summary = [[trade_account, pnl_sum, 'Valuation', trade_strategy]]            
    return pnl_stats, pnl_stats_summary, df_orders_stats_pnl, orders_liveexposure, orders_noprice
    

#%% get instrument price data
def func_pnlrecord_get_price(date_beg, date_end, df_symbol_infor, tc, traxexcore, indicators):
    instrument_infor = []
    
    time_beg = date_beg.date()
    time_end = date_end.date() + datetime.timedelta(days=1)        
    for idx in range(len(df_symbol_infor)):
        try:
            instrument = df_symbol_infor.symbol[idx]
            exchange = df_symbol_infor.exchange[idx]
            try:
                if math.isnan(exchange)==1:
                    exchange=''
            except:
                a=1
            sec = traxexcore.get_symbol(instrument+exchange)
            params = 'DAYS_BACK:0,DAYS_BACKDATE:0,START_DATE:{0},END_DATE:{1},MINUTE_INTERVAL:1,LIVE_DATA:0,SUBSCRIPTION:0'.format(time_beg, time_end)
            df_bar = indicators.io.OHLCBar(tc,sec,params).P
            df_bar['dt'] = df_bar['dt'] + datetime.timedelta(minutes=1)
            df_bar.set_index('dt', inplace=True)            
            instrument_infor = instrument_infor + [[df_symbol_infor.symbol[idx], dict(symbol=df_symbol_infor.symbol[idx], currency=df_symbol_infor.currency[idx], \
                                                       asset=df_symbol_infor.asset[idx], multiplier=df_symbol_infor.multiplier[idx], price=df_bar)]]
        except:
            instrument_infor = instrument_infor + [[df_symbol_infor.symbol[idx], dict(symbol=df_symbol_infor.symbol[idx], currency=df_symbol_infor.currency[idx], \
                                                       asset=df_symbol_infor.asset[idx], multiplier=df_symbol_infor.multiplier[idx], price=pd.DataFrame([]))]]
            print(instrument+' - data error!')
    return instrument_infor

#%% get currency rate
def func_pnlrecord_get_currency(date_beg, date_end, tc, traxexcore, indicators, option='last'):
    
    dict_currency2value = dict(USD=1)
    
    time_beg = date_beg.date()
    time_end = date_end.date()
    
    sec = traxexcore.get_symbol('EURUSD')
    params = 'DAYS_BACK:0,DAYS_BACKDATE:0,START_DATE:{0},END_DATE:{1},MINUTE_INTERVAL:1,LIVE_DATA:0,SUBSCRIPTION:0'.format(time_beg, time_end)
    df_bar = indicators.io.OHLCBar(tc,sec,params).P
    dict_currency2value['EUR'] = df_bar.close.values[-1]
    
    sec = traxexcore.get_symbol('GBPUSD')
    params = 'DAYS_BACK:0,DAYS_BACKDATE:0,START_DATE:{0},END_DATE:{1},MINUTE_INTERVAL:1,LIVE_DATA:0,SUBSCRIPTION:0'.format(time_beg, time_end)
    df_bar = indicators.io.OHLCBar(tc,sec,params).P
    dict_currency2value['GBP'] = df_bar.close.values[-1]
    
    sec = traxexcore.get_symbol('AUDUSD')
    params = 'DAYS_BACK:0,DAYS_BACKDATE:0,START_DATE:{0},END_DATE:{1},MINUTE_INTERVAL:1,LIVE_DATA:0,SUBSCRIPTION:0'.format(time_beg, time_end)
    df_bar = indicators.io.OHLCBar(tc,sec,params).P
    dict_currency2value['AUD'] = df_bar.close.values[-1]
    
    sec = traxexcore.get_symbol('NZDUSD')
    params = 'DAYS_BACK:0,DAYS_BACKDATE:0,START_DATE:{0},END_DATE:{1},MINUTE_INTERVAL:1,LIVE_DATA:0,SUBSCRIPTION:0'.format(time_beg, time_end)
    df_bar = indicators.io.OHLCBar(tc,sec,params).P
    dict_currency2value['NZD'] = df_bar.close.values[-1]
    
    sec = traxexcore.get_symbol('USDJPY')
    params = 'DAYS_BACK:0,DAYS_BACKDATE:0,START_DATE:{0},END_DATE:{1},MINUTE_INTERVAL:1,LIVE_DATA:0,SUBSCRIPTION:0'.format(time_beg, time_end)
    df_bar = indicators.io.OHLCBar(tc,sec,params).P
    dict_currency2value['JPY'] = 1/df_bar.close.values[-1]
    
    sec = traxexcore.get_symbol('USDCHF')
    params = 'DAYS_BACK:0,DAYS_BACKDATE:0,START_DATE:{0},END_DATE:{1},MINUTE_INTERVAL:1,LIVE_DATA:0,SUBSCRIPTION:0'.format(time_beg, time_end)
    df_bar = indicators.io.OHLCBar(tc,sec,params).P
    dict_currency2value['CHF'] = 1/df_bar.close.values[-1]
    
    sec = traxexcore.get_symbol('USDCAD')
    params = 'DAYS_BACK:0,DAYS_BACKDATE:0,START_DATE:{0},END_DATE:{1},MINUTE_INTERVAL:1,LIVE_DATA:0,SUBSCRIPTION:0'.format(time_beg, time_end)
    df_bar = indicators.io.OHLCBar(tc,sec,params).P
    dict_currency2value['CAD'] = 1/df_bar.close.values[-1]
    
    sec = traxexcore.get_symbol('USDCNH')
    params = 'DAYS_BACK:0,DAYS_BACKDATE:0,START_DATE:{0},END_DATE:{1},MINUTE_INTERVAL:1,LIVE_DATA:0,SUBSCRIPTION:0'.format(time_beg, time_end)
    df_bar = indicators.io.OHLCBar(tc,sec,params).P
    dict_currency2value['CNH'] = 1/df_bar.close.values[-1]
    
    sec = traxexcore.get_symbol('USDHKD')
    params = 'DAYS_BACK:0,DAYS_BACKDATE:0,START_DATE:{0},END_DATE:{1},MINUTE_INTERVAL:1,LIVE_DATA:0,SUBSCRIPTION:0'.format(time_beg, time_end)
    df_bar = indicators.io.OHLCBar(tc,sec,params).P
    dict_currency2value['HKD'] = 1/df_bar.close.values[-1]
    
    sec = traxexcore.get_symbol('USDSGD')
    params = 'DAYS_BACK:0,DAYS_BACKDATE:0,START_DATE:{0},END_DATE:{1},MINUTE_INTERVAL:1,LIVE_DATA:0,SUBSCRIPTION:0'.format(time_beg, time_end)
    df_bar = indicators.io.OHLCBar(tc,sec,params).P
    dict_currency2value['SGD'] = 1/df_bar.close.values[-1]
    
    sec = traxexcore.get_symbol('USDINR')
    params = 'DAYS_BACK:0,DAYS_BACKDATE:0,START_DATE:{0},END_DATE:{1},MINUTE_INTERVAL:1,LIVE_DATA:0,SUBSCRIPTION:0'.format(time_beg, time_end)
    df_bar = indicators.io.OHLCBar(tc,sec,params).P
    dict_currency2value['INR'] = 1/df_bar.close.values[-1]
    
    sec = traxexcore.get_symbol('XAUUSD')
    params = 'DAYS_BACK:0,DAYS_BACKDATE:0,START_DATE:{0},END_DATE:{1},MINUTE_INTERVAL:1,LIVE_DATA:0,SUBSCRIPTION:0'.format(time_beg, time_end)
    df_bar = indicators.io.OHLCBar(tc,sec,params).P
    dict_currency2value['XAU'] = df_bar.close.values[-1]
    
    return dict_currency2value
