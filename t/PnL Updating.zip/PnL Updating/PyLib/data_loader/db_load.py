### The Class that Connect DB to query price and volume information
### author: Zhao Rui, Quant, Harveston
import pg8000
import pandas as pd
from cassandra.cluster import Cluster, tuple_factory

"""
GLOBAL VAR DEFINITION for DB Access
"""
CASS_RD_HOST = '192.168.1.14'
CASS_LIVE_HOST = '172.30.1.217'
SQLDBHOST = '172.30.1.139'
SQLPORT = 5532
SQLPASSWORD = 'Alice1989'


class DBload(object):
    def __init__(self, market_name=""):
        """
        Query DB to get the data based on market names [HK, CN, US]
        Input:
            @market_name: supports HK, CN and US 
        """
        self.market_name = market_name

    
    def connect_db(self, mode='research'):
        """
        connect the db
        Input:
            @mode: use the production db if live else use the research db 
        """
        if mode == 'research':
            cassandra_ip = CASS_RD_HOST
        else:
            cassandra_ip = CASS_LIVE_HOST
        self.cluster = Cluster([cassandra_ip])
        self.session = self.cluster.connect('historical_database')
        self.session.default_timeout = 60
        self.session.row_factory = tuple_factory     



    def query_ids(self, symbols=""):
        """
        query the symbol id
        Input:
                @symbols: a list of symbols (str type), if empty get all symbols under self.market
        For stocks, suggest symbols are provided

        self.oids and self.secs are created as dataframe with stock name, oid and exchangeid
        """
        conn = pg8000.connect(host=SQLDBHOST, port=SQLPORT, 
                                   database='SecurityDatabase', user='postgres', password=SQLPASSWORD)
        if self.market_name == 'HK' or self.market_name == 'US':
            if symbols == "":
                cmd = '''
                    select oid, a.name, b.name from sec_security a, sec_exchange b 
                    where ver_to_instant > NOW() and
                    a.sec_exchange_id=b.id and b.name='{}'
                    '''.format(self.market_name)         
            else:
                slist = [str(ele) for ele in symbols]
                if len(slist) == 1:
                    slist = slist + slist
                cmd = '''
                    select oid, a.name, b.name from sec_security a, sec_exchange b 
                    where ver_to_instant > NOW() and
                    a.sec_exchange_id=b.id and b.name='{}' and a.name IN {}
                    '''.format(self.market_name, tuple(slist))             
            with conn.cursor() as cursor:
                cursor.execute(cmd)
            secs = []
            for r in cursor.fetchall():
                secs.append({ 'oid': r[0], 'symbol': r[1] })
            self.secs = pd.DataFrame(secs)
            self.oids = list(set(self.secs.oid.values))

        if self.market_name == 'CN':
            sec_list = []
            for mk_name in ['SS', 'SZ']:
                cmd = '''
                    select oid, a.name, b.name from sec_security a, sec_exchange b 
                    where ver_to_instant > NOW() and
                    a.sec_exchange_id=b.id and b.name='{}'
                    '''.format(mk_name) 
                with conn.cursor() as cursor:
                    cursor.execute(cmd)
                secs = []
                for r in cursor.fetchall():
                    secs.append({ 'oid': r[0], 'symbol': r[1] })
                sec_list.append(pd.DataFrame(secs))
            self.secs = pd.concat(sec_list) 
            if symbols != "":
                slist = [str(ele) for ele in symbols]
                pd_stocklist = pd.DataFrame(slist, columns=['symbol'])
                self.secs = self.secs.merge(pd_stocklist, on=['symbol'])
                self.oids = list(set(self.secs.oid.values))
            else:
                self.oids = list(set(self.secs.oid.values))

        if self.market_name == "":
            if symbols == "":
                raise ValueError("symbols should be provided")
            else:
                slist = [str(ele) for ele in symbols]
                if len(slist) == 1:
                    slist = slist + slist
                cmd = """
                  select oid, name from sec_security where ver_to_instant > NOW() 
                  and name IN {}
                  """.format(tuple(slist))
                with conn.cursor() as cursor:
                    cursor.execute(cmd)
                secs = []
                for r in cursor.fetchall():
                    secs.append({ 'oid': r[0], 'symbol': r[1]})
                self.secs = pd.DataFrame(secs)
                self.oids = list(set(self.secs.oid.values))
        conn.close()

    def get_prices_batch(self, sdate, min_interval=1440, volume_on=True, edate='2050-12-01'):
        """
        Query DB to get the features from the cassandra DB during the set time range.
        Input:
            @sdate: the starting day
            @edate: the ending day
        """
        if volume_on:
            if len(self.oids) > 1:
                cmd ="""select sec_id, dt,open,high,low,close,volume from hts_historical_bar where sec_interval={} and
                        sec_id IN {} and
                        dt >= '{}' and dt < '{}';""".format(min_interval*60, tuple(self.oids), sdate, edate)
            else:
                 cmd ="""select sec_id, dt,open,high,low,close,volume from hts_historical_bar where sec_interval={} and
                        sec_id={} and
                        dt >= '{}' and dt < '{}';""".format(min_interval*60, self.oids[0], sdate, edate)               
            results = self.session.execute(cmd)
            results = [row for row in results]
            df_price = pd.DataFrame(results, columns=['oid', 'date', 'open', 'high', 'low', 'close', 'volume'])
        else:
            if len(self.oids) > 1:
                cmd ="""select sec_id, dt,open,high,low,close from hts_historical_bar where sec_interval={} and
                        sec_id IN {} and
                        dt >= '{}' and dt < '{}';""".format(min_interval*60, tuple(self.oids), sdate, edate)
            else:
                 cmd ="""select sec_id, dt,open,high,low,close from hts_historical_bar where sec_interval={} and
                        sec_id={} and
                        dt >= '{}' and dt < '{}';""".format(min_interval*60, self.oids[0], sdate, edate) 
            results = self.session.execute(cmd)
            results = [row for row in results]
            df_price = pd.DataFrame(results, columns=['oid', 'date', 'open', 'high', 'low', 'close'])           

        df_price = df_price.merge(self.secs, on=['oid'])
        df_price = df_price.sort_values(by=['symbol', 'date'])
        df_price.drop(columns=['oid'], inplace=True)
        return df_price


    def close_db(self):
        """
        when data prepared, close the db connection
        """
        self.session.shutdown()
        self.cluster.shutdown()
