# data_loader

This package is for querying price and volume infos. from cassandra databas. 

## Pre-required Packages

1.cassandra-driver==3.15.1

2.pg8000==1.12.3

## Usage
```python
from data_loader.db_load import DBload
#market name, due to some overlapping keys, the market name should be given for some products
db = DBload('US')
db.connect_db()
#[p_name] is the list of symbols
db.query_ids([p_name])
start_day = '2018-08-02'
min_interval = 1
df_price = db.get_prices_batch(start_day, min_interval) # get one minute data from start_day
#for some currency products,set volumne_on =False
```
