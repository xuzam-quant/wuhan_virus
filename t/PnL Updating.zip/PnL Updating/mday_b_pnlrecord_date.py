# -*- coding: utf-8 -*-
"""
Created on Mon May 13 14:23:20 2019

@author: zhangxu
"""

import numpy as np
import pandas as pd
import os
import sys
import datetime
import pickle
from openpyxl import load_workbook
from asim import traxexcore
from asim import indicators
sys.path.append(os.getcwd()+'\\PyLib')
from FunctionList import *

date_stats_beg  = datetime.datetime(2019,2,1)
date_stats_end  = datetime.datetime.now().replace(hour=0, minute=0, second=0, microsecond=0) + datetime.timedelta(days=1)
date_record_beg = datetime.datetime(2019,3,1)
datetime_pnlcut = datetime.timedelta(hours=16, minutes=30)

foldername_order  = 'Data\\MDay\\Account\\'
foldername_date   = 'Data\\MDay\\Date\\'
filename_excel    = 'mday_report_summary_2019.xlsx'
sheetname_account = 'TradeAccount'
sheetname_symbol  = 'SymbolInfor'
sheetname_accountsummary    = 'AccountSummary'
sheetname_accountdetail     = 'AccountDetail'
sheetname_accountdetaildate = 'AccountDetailDate'
sheetname_ordernoprice      = 'OrdersNoPrice'
sheetname_liveexposure      = 'LiveExposure'

df_trade_account = pd.read_excel(filename_excel, sheetname=sheetname_account)
df_symbol_infor  = pd.read_excel(filename_excel, sheetname=sheetname_symbol)
tc = traxexcore.TraxexCore('.\\traxexcore.xml')
#%% initialize
if os.path.exists(foldername_date)==0:
    os.makedirs(foldername_date)
    
dict_currency2value = func_pnlrecord_get_currency(date_stats_end-datetime.timedelta(days=15), date_stats_end, tc, traxexcore, indicators, option='last')
instrument_infor    = func_pnlrecord_get_price(date_stats_beg, date_stats_end, df_symbol_infor, tc, traxexcore, indicators)

book = load_workbook(filename_excel)
writer = pd.ExcelWriter(filename_excel, engine='openpyxl')
writer.book = book
del writer.book[sheetname_accountsummary]
del writer.book[sheetname_accountdetail]
del writer.book[sheetname_accountdetaildate]
del writer.book[sheetname_liveexposure]
del writer.book[sheetname_ordernoprice]
writer.sheets = dict((ws.title,ws) for ws in book.worksheets)

#%% pnl calculation
PnL_stats_accountdetaildate = [['instrument', 'pnl_raw', 'converter', 'pnl_final', 'asset', 'amt_net_sum', 'accounting', 'trade_account', 'trade_strategy', 'date']]
date_stats_endcut = date_stats_end
while date_stats_endcut>=date_record_beg:
    print('--------------------------------')
    print(date_stats_endcut+datetime_pnlcut)
    
    filename_ystd = foldername_date + (date_stats_endcut+datetime_pnlcut).strftime("%Y%m%d_%H%M") + '.pickle'
    if os.path.exists(filename_ystd)==0 or date_stats_endcut==date_stats_end:
        PnL_stats_accountdetail      = [['instrument', 'pnl_raw', 'converter', 'pnl_final', 'asset', 'amt_net_sum', 'accounting', 'trade_account', 'trade_strategy', 'date']]
        PnL_stats_accountsummary     = [['trade_account', 'pnl_final', 'accounting', 'trade_strategy']]
        Orders_stats_ordernoprice    = [['date', 'time', 'account', 'price', 'quantity', 'side', 'symbol', 'type']]
        Orders_stats_liveexposure    = [['account', 'date', 'instrument', 'exposure', 'amt', 'price', 'converter', 'time']]
        
        stats_settle_time_beg = date_stats_beg+datetime_pnlcut
        stats_settle_time_end = date_stats_endcut+datetime_pnlcut
                
        for idx_account in range(len(df_trade_account)):
            trade_account  = df_trade_account.Account[idx_account]
            df_orders = pd.read_csv(foldername_order+trade_account+'\\'+trade_account+'.csv')
            df_orders['time'] = pd.to_datetime(df_orders['time'])
            if len(df_orders)==0:
                continue
            
            pnl_stats, pnl_stats_summary, df_orders_stats_pnl, orders_liveexposure, orders_noprice = \
            func_pnlrecord_get_pnl(df_orders, stats_settle_time_beg, stats_settle_time_end, \
                                   df_trade_account.iloc[idx_account], instrument_infor, dict_currency2value)            
            if date_stats_endcut==date_stats_end:
                with open(foldername_order+trade_account+'\\'+trade_account+'.pickle', 'wb') as f:
                    pickle.dump(dict(df_orders_stats_pnl=df_orders_stats_pnl, pnl_stats=pnl_stats, pnl_stats_summary=pnl_stats_summary, orders_liveexposure=orders_liveexposure),f)

            PnL_stats_accountdetail  = PnL_stats_accountdetail  + pnl_stats
            PnL_stats_accountsummary = PnL_stats_accountsummary + pnl_stats_summary                
            Orders_stats_liveexposure = Orders_stats_liveexposure + orders_liveexposure
            Orders_stats_ordernoprice = Orders_stats_ordernoprice + orders_noprice
            
        df_PnL_stats_accountdetail = pd.DataFrame(PnL_stats_accountdetail[1:],columns=PnL_stats_accountdetail[0])
        df_PnL_stats_accountsummary = pd.DataFrame(PnL_stats_accountsummary[1:],columns=PnL_stats_accountsummary[0])            
        df_Orders_stats_liveexposure = pd.DataFrame(Orders_stats_liveexposure[1:],columns=Orders_stats_liveexposure[0])
        df_Orders_stats_ordernoprice = pd.DataFrame(Orders_stats_ordernoprice[1:],columns=Orders_stats_ordernoprice[0])
        if date_stats_endcut==date_stats_end:
            df_PnL_stats_accountdetail.to_excel(writer,  sheet_name=sheetname_accountdetail, index=False)
            df_PnL_stats_accountsummary.to_excel(writer, sheet_name=sheetname_accountsummary, index=False)
            df_Orders_stats_liveexposure.to_excel(writer, sheet_name=sheetname_liveexposure, index=False)
            df_Orders_stats_ordernoprice.to_excel(writer, sheet_name=sheetname_ordernoprice, index=False)
                        
        if datetime.datetime.now()>stats_settle_time_end:
            with open(filename_ystd, 'wb') as f:
                pickle.dump(dict(df_PnL_stats_accountdetail=df_PnL_stats_accountdetail, df_Orders_stats_liveexposure=df_Orders_stats_liveexposure),f)
            
    else:
        with open(filename_ystd, 'rb') as f:
            df_PnL_stats_accountdetail = pickle.load(f)['df_PnL_stats_accountdetail']                
    
    PnL_stats_accountdetaildate = PnL_stats_accountdetaildate + df_PnL_stats_accountdetail[['instrument', 'pnl_raw', 'converter', 'pnl_final', 'asset', 'amt_net_sum', 'accounting', 'trade_account', 'trade_strategy', 'date']].values.tolist()    
    date_stats_endcut = date_stats_endcut - datetime.timedelta(days=1)
    
df_PnL_stats_accountdetaildate = pd.DataFrame(PnL_stats_accountdetaildate[1:],columns=PnL_stats_accountdetaildate[0])
df_PnL_stats_accountdetaildate.to_excel(writer, sheet_name=sheetname_accountdetaildate, index=False)  
writer.save()
